#include <iostream>
#include <string>
using namespace std;

class ModInt{
private:
  int mod;
  int val;
public:

  ModInt(int m, int v);
  ModInt();

  int getMod(){
    return mod;
  }
  int getVal(){
    return val;
  }

void operator += (ModInt rhs);

};

ModInt::ModInt(int m, int v){
  mod = m;
  val = v;
}
ModInt::ModInt(){
  mod = 1;
  val = 0;
}

bool operator ==(ModInt lhs, ModInt rhs){
  if(lhs.getMod()==rhs.getMod()&&lhs.getVal()==rhs.getVal()){
    return true;
  }else{
    return false;
  }
}

void ModInt::operator += (ModInt rhs){
  if(getMod()==rhs.getMod()){
    val=(getVal()+rhs.getVal())%getMod();
  }else{
    mod=-1;
    val=-1;
  }
}

int main(){

  ModInt test1;
  ModInt test2(2,5);

test1+=test2;
cout<<test1.getVal()<<endl;
}
