#include <iostream>
#include <string>
using namespace std;

class ModInt{
private:
  int mod;
  int val;
public:

  ModInt(int m, int v);

  ModInt();

  int getMod(){
    return mod;
  }
  int getVal(){
    return val;
  }
};

ModInt::ModInt(int m, int v){
  mod = m;
  val = v;
}
ModInt::ModInt(){
  mod = 1;
  val = 0;
}

int main(){

  ModInt test1;
  ModInt test2(5,4);

cout<<test1.getMod()<<test1.getVal()<<endl;
}
