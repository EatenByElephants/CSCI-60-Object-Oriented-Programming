#include <iostream>
#include "bag.cpp"

using namespace std;

int main(){
  bag<int> b;
  for (int i=0; i<5; i++) {
    b.insert(i);
  }
  for (auto e : b) cout << e << endl;
  cout<< endl;
  for (bag<int>::iterator it = b.begin(); it!=b.end(); it++){
    cout << *it << endl;
  }
}
