#include <iostream>
#include <string>
#include "dbiguint.h"

using namespace std;

int main(){
  dbiguint result("000000000004243");
  dbiguint result2("6088");
  //result+=result2;
  cout<<result<<endl;

  result.clean();
  cout<<result<<endl;

}
