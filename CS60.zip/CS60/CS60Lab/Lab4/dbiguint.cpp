

#include <iostream>
#include <string>
#include "dbiguint.h"


//default constructor
dbiguint::dbiguint(){
  capacity_=1;
  data_ = new unsigned short[1];
  data_[0]=0;
  }

//Construtor taking in the string. Subtracts character 0 to find the actual digit
dbiguint::dbiguint(const std::string & y){
  capacity_ = y.length();
  data_ = new unsigned short[capacity_];
  int k = 0;
  for(std::size_t j = y.length()-1;j > 0;j--){
    data_[k] = y[j] - '0';
    k++;
  }
  data_[y.length()-1] = y[0] - '0';
  for(std::size_t i = y.length();i < capacity_ ;i++){
    data_[i] = 0;
  }
}

std::size_t dbiguint::size() const{
  return capacity_;
}

//Returns index within []
unsigned short dbiguint::operator [](std::size_t pos) const {
  if(pos > capacity_){
    return 0;
  }
  else{
    return data_[pos];
  }
}


//Allows printing of biguint
std::ostream & operator << (std::ostream&out, const dbiguint & b){
  for(std::size_t i = b.size()-1; i > 0;i--){
    out<<b[i];
  }
  out<<b[0];
  return out;
}

void dbiguint::reserve(std::size_t newcapacity_){
  if(newcapacity_>capacity_){
    unsigned short * temp= new unsigned short[newcapacity_];
    for(int i=0;i<capacity_;i++){
      temp[i]=data_[i];
    }
    for(std::size_t i=newcapacity_-1;i>=capacity_;i--){
      temp[i]=0;
    }
    delete [] data_;
    capacity_=newcapacity_;
    data_=temp;
    capacity_=newcapacity_;
    temp = nullptr;
  }
}


//Allows += of two biguints
void dbiguint::operator += (const dbiguint & b){

if(capacity_<=b.size()){
  reserve(b.size());
}
int carry = 0;
for(std::size_t i = capacity_ - 1;i > 0;i--){
  carry = data_[i-1] + b[i-1];
  if(carry > 9){
    data_[i] = data_[i] + b[i] +1;
    if(data_[i]>9){
      data_[i]=data_[i]-10;
    }
  }else{
    data_[i] = data_[i] + b[i];
  }
}
  data_[0] = data_[0] + b[0];
  if(data_[0]>9){
    data_[0]=data_[0]-10;
  }
}

dbiguint::~dbiguint(){
  delete [] data_;
  data_=nullptr;
  capacity_=0;
}

void dbiguint::clean(){
  std::string a;
  for(std::size_t i = size(); i > 0;i--){
      a+= std::to_string(data_[i-1]);
  }
  int index;
  for(std::size_t j = 0; j< a.length();j++){
    if(a[j]!='0'){
      index = j;
      break;
    }
  }
std::string b;
  for(std::size_t k = index; k< a.length();k++){
    b+=a[k];
  }

  delete data_;
  capacity_ = b.length();
  data_ = new unsigned short[capacity_];
  int m = 0;
  for(std::size_t l = b.length()-1;l > 0;l--){
    data_[m] = b[l] - '0';
    m++;
  }
  data_[b.length()-1] = b[0] - '0';
}
/*
//Adds two biguints and outputs result
biguint operator + (const biguint & a, const biguint & b){
  biguint result;
  result+=a;
  result+=b;
  return result;
}

//Compares two biguints
// returns 1 if this biguint > b
//               0 if this biguint == b
//              -1 if this biguint < b
int biguint::compare(const biguint & b) const{
  int count = 0;
  for(std::size_t i = biguint::CAPACITY - 1;i>0;i--){
if(data_[i]<b[i]){
  return -1;
  break;
}else if(data_[i]>b[i]){
  return 1;
  break;
}else{
  count++;
}
}
if(data_[0]<b[0]){
  return -1;
}else if(data_[0]>b[0]){
  return 1;
}else{
  count++;
}
if(count == biguint::CAPACITY){
  return 0;
}
}

//Returns true or false for <
bool operator < (const biguint &a, const biguint &b){
  int c = a.compare(b);
  if(c ==-1){
    return true;
  }else{
    return false;
  }
}

//Returns true or false for <=
bool operator <= (const biguint & a, const biguint & b){
  int c = a.compare(b);
  if(c==-1||c==0){
    return true;
  }else{
    return false;
  }
}

//Returns true or false for !=
bool operator != (const biguint &a, const biguint &b){
  int c = a.compare(b);
  if(c!=0){
    return true;
  }else{
    return false;
  }
}

//Returns true or false for ==
bool operator == (const biguint &a, const biguint &b){
  int c = a.compare(b);
  if(c==0){
    return true;
  }else{
    return false;
  }
}

//Returns true or false for >=
bool operator >= (const biguint &a, const biguint &b){
  int c = a.compare(b);
  if(c==1||c==0){
    return true;
  }else{
    return false;
  }
}

//Returns true or false for >
bool operator > (const biguint &a, const biguint &b){
  int c = a.compare(b);
  if(c==1){
    return true;
  }else{
    return false;
  }
}

//Allows -= of two biguints (absolute value of result)
void biguint::operator -= (const biguint & b){
  int sub = 0;
  int borrow = 0;
  for(std::size_t i = CAPACITY - 1;i > 0;i--){
    sub = data_[i] - b.data_[i];
    if(sub < 0){
      borrow = 1;
    }
    else{
      borrow = 0;
    }
    if(borrow == 1){
      data_[i] = (data_[i] - b.data_[i])*(-1);
    }
    else{
      data_[i] = data_[i] - b.data_[i];
    }
  }
  if(sub < 0){
    borrow = 1;
  }
  else{
    borrow = 0;
  }
  if(borrow == 1){
    data_[0] = (data_[0] - b.data_[0])*(-1);
  }
  else{
    data_[0] = data_[0] - b.data_[0];
  }
}

//Subtracts one biguint from another and outputs absolute value of result
biguint operator - (const biguint & a, const biguint & b){
  biguint result;
  result+=a;
  result-=b;
  return result;
}

//Reverses the constructer that intakes a string by adding back character 0
//Outputs biguint as a string
std::string biguint::toString(){
  std::string Int;
  for(std::size_t i = biguint::CAPACITY - 1;i > 0;i--){
  Int+= data_[i]+'0';
}
Int+=data_[0]+'0';
return Int;
}
*/
