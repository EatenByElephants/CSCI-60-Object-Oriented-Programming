#include <iostream>

using namespace std;

double water(int n);
bool isSorted(int a[], int n);

int main(){
cout<<water(2)<<endl;
int a[] = {1,2,0,5,6};
cout<<isSorted(a,5)<<endl;

}

double water(int n){
  if (n==0) return 10;
  else return (water(n-1)/2)+1;
}

bool isSorted(int a[], int n){
  if(n==1) return true;
  else if(a[n-1]<a[n-2]) return false;
  else return isSorted(a,n-2);
}
