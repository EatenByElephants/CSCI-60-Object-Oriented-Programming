#include "node.h"
#include <iostream>

using namespace std;

int main(){
  node *head = new node(4,nullptr);
  node *tail(head);
  node *temp;

  head = new node(5,head);
  head = new node(7,head);

  cout<<list_index(head,7)<<endl;
  cout<<list_at(head,0)->data()<<endl;
}
