#include <iostream>
#include <vector>
#include <string>
#include <fstream>

using namespace std;

int main(){
vector<string> v;

int count = 0;
string a;
ifstream in;
in.open("lab4.txt");
while(getline(in,a)){
  v.push_back(a);
  count++;
}
in.close();

ofstream out;
out.open("c.txt");
for(auto e: v)
  out << e <<endl;
out.close();

//B1a
cout<< count<<endl;
}
