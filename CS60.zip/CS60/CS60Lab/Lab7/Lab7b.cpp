#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <fstream>

using namespace std;

int main(){
map<string,int> m;

  double count = 0;
  double total = 0;
  string a;
  ifstream in;
  in.open("lab4.txt");
  while(getline(in,a)){
    m[a]+=1;
    total++;
  }
  in.close();

  ofstream out;
  out.open("b.txt");
  for(auto e: m){
    out << e.first << " " << e.second <<endl;
    count++;
  }
  out.close();

  //B1c
  double ave = total/count;
  cout << ave << endl;
}
