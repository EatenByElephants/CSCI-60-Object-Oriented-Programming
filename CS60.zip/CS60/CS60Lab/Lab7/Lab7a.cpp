#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <unordered_set>

using namespace std;

int main(){
unordered_set<string> s;

  int count = 0;
  string a;
  ifstream in;
  in.open("lab4.txt");
  while(getline(in,a)){
    s.insert(a);
  }
  in.close();

  ofstream out;
  out.open("a.txt");
  for(auto e: s) {
    out << e <<endl;
    count++;
  }
  out.close();

//B1b
cout << count <<endl;
}
