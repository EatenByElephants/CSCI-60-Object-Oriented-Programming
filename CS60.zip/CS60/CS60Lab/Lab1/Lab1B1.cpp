#include <iostream>
#include <cstring>

using namespace std;

Struct Time{
  int hour;
  int minute;
};

Struct Carpool{
  string names[5];
  int numb;
  Time arrival;
};
