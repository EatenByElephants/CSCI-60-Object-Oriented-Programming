#include <iostream>
#include <cstring>

using namespace std;

struct Time{
  int hour;
  int minute;
};

struct Carpool{
  string names[5];
  int num;
  Time arrival;
};

Time earlier (Time t1, Time t2)
{
  return t1;
}

Carpool combineCarpool(Carpool car1, Carpool car2)
{
  Carpool result;

  string people[car1.num+car2.num];

  if (car1.num+car2.num>5){
    result.num=0;
    return result;
  }else{
    result.arrival = earlier (car1.arrival,car2.arrival);
    result.num = car1.num+car2.num;

    for (int i=0;i<car1.num;i++){
      people[i]=car1.names[i];
    }
    for(int j=car1.num;j<result.num;j++){
      people[j]=car2.names[j-car1.num];
    }
    for(int k=0;k<result.num;k++){
    result.names[k] = people[k];
  }
  }

  for(int k=0;k<result.num;k++){
  cout<<result.names[k]<<endl;
}

cout<<result.num<<endl;
cout<<result.arrival.hour<<endl;
cout<<result.arrival.minute<<endl;

  return result;

}

int main(){

  Time t1 = {1,2};
  Time t2 = {2,3};

  Carpool redCar = {"Jeff","","","","",1,t1};
  Carpool blueCar = {"Brian","Sam","","","",2,t2};

  combineCarpool(redCar,blueCar);

}
