#include <iostream>
#include "automobile.h"
#include "pickup.h"
#include "van.h"

using namespace std;

int main(){

Automobile car("brand", "type", 1, 1, 1);
bool spots[10]={false};
car.park(spots,10);

Pickup truck(1,5,"brand", "type", 1, 1, 1);
truck.park(spots,10);

Van big(8,"brand", "type", 1, 1, 1);
big.park(spots,10);

Van small(6,"brand", "type", 1, 1, 1);
small.park(spots,10);


for(int i=0;i<10;i++){
cout<<spots[i]<<endl;
}
}
