#include "pickup.h"

Pickup::Pickup(): Automobile(){
  cab_=0;
  capacity_=0;
}

Pickup::Pickup(bool cab, int capacity,std::string imake, std::string imodel, int iyear, double iprice, int istall): Automobile(imake, imodel, iyear, iprice, istall){
  cab_=cab;
  capacity_=capacity;
}

bool Pickup::park(bool lot[], int size){
    int spot=size;
    for(int i=0; i<size; i++){
        if(!lot[i]&&!lot[i-1])
            spot = i;
    }
    if(spot>=size)
       return false;
    else{
        lot[spot] = true;
        lot[spot-1]=true;
        set_stall(spot);
        return true;
    }
}
