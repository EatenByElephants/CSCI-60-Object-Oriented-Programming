#ifndef PICKUP_H
#define PICKUP_H
#include <string>
#include "automobile.h"

class Pickup: public Automobile
{
public:
  Pickup();
  Pickup(bool cab, int capacity,std::string imake, std::string imodel, int iyear, double iprice, int istall);
  bool park(bool lot[], int size);
  bool hasCab(){return cab_;}
  int haulCap(){return capacity_;}
private:
  int capacity_;
  bool cab_;
};




#endif // PICKUP_H
