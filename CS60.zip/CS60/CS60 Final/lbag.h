// Q3 final exam starter code: class definitions & implementations (from Day 24)
// for templatized node, L_iterator, and LBag classes; don't modify or upload!
// Sara Krehbiel, 3/16/20

#ifndef LBAG_H
#define LBAG_H

#include <cstdlib>
#include <ostream>
#include <iostream>

using std::size_t;


/* INTERFACE FOR NODE FOR LINKED LISTS */

template<typename T>
class node {
public:
  node(const T & d = T(), node<T> * l = nullptr) : data_(d), link_(l) {}
  T data() const { return data_; }
  node<T> * link() const { return link_; }
  void set_data(const T & newdata) { data_ = newdata; }
  void set_link(node<T> * newlink) { link_ = newlink; }
private:
  T data_;
  node<T> * link_;
};

// declarations for node-related non-member functions (defined below)

template<typename T> // insert data of each elem starting from head into out
std::ostream& operator <<(std::ostream& out, const node<T> * head);

template<typename T> // count #nodes from head to nullptr
std::size_t list_size(const node<T> * head);

template<typename T> // put new node with specified val before head of list
void list_insert_head(node<T>*& head, node<T>*& tail, const T& val);

template<typename T> // put new node with specified val behind tail of list
void list_insert_tail(node<T>*& head, node<T>*& tail, const T& val);

template<typename T> // remove first node from list
void list_remove_head(node<T>*& head, node<T>*& tail);

template<typename T> // remove last node from list
void list_remove_tail(node<T>*& head, node<T>*& tail);


/* INTERFACE & IMPLEMENTATION FOR L_ITERATOR FOR LINKED LIST DATA STRUCTURES */

template <typename T>
class L_iterator {
public:
  L_iterator(node<T>* p = nullptr) : curr(p) {}
  T operator *() const { return curr->data(); }
  bool operator ==(const L_iterator<T>& rhs) const { return (curr==rhs.curr); }
  bool operator !=(const L_iterator<T>& rhs) const { return (curr!=rhs.curr); }
  L_iterator<T>& operator ++() { curr = curr->link(); return (*this); }
  L_iterator<T> operator ++(int) { L_iterator<T> old(*this); curr = curr->link(); return old; }
private:
  node<T> * curr;
};


/* INTERFACE & PARTIAL INLINE IMPLEMENTATION FOR LBAG DATA STRUCTURE */

template <typename T>
class LBag {
public:
  typedef L_iterator<T> iterator;
  LBag() : head(nullptr), tail(nullptr) {}
  LBag(const LBag<T> & b);
  ~LBag() { while (head!=nullptr) list_remove_head(head,tail); }
  void operator =(const LBag<T> & b);
  iterator begin() { return iterator(head); }
  iterator end() { return iterator(); }
  size_t size() const { return list_size(head); }
  size_t count(const T & target) const;
  void insert(const T & target) { list_insert_head(head,tail,target); }
  bool erase_one(const T & target);
  size_t erase(const T & target);
  template<typename T2>
  friend std::ostream & operator <<(std::ostream & out, const LBag<T2> & b) { return out << b.head; }
private:
  node<T> *head, *tail;
};


/* OUT-OF-LINE MEMBER FUNCTION DEFINITIONS FOR LBAG */

template<typename T> // copy constructor
LBag<T>::LBag(const LBag<T> & b) {
  head = tail = nullptr;
  for (node<T> * p = b.head; p != nullptr; p = p->link()) {
    list_insert_tail(head,tail,p->data());
  }
}

template<typename T> // assignment operator
void LBag<T>::operator =(const LBag<T> &b) {
  this->~LBag<T>();
  for (node<T> * p = b.head; p != nullptr; p = p->link()) {
    list_insert_tail(head,tail,p->data());
  }
}

template<typename T> // count #elems with target data
size_t LBag<T>::count(const T & target) const {
  size_t count=0;
  for (const node<T> * p=head; p!=nullptr; p=p->link()) {
    if (p->data() == target) count++;
  }
  return count;
}

template<typename T> // return whether target is found, erase first if so
bool LBag<T>::erase_one(const T & target) {
  node<T> * prev = nullptr;
  for (node<T> * p = head; p != nullptr; p = p->link()) {
    if (p->data() == target) {
      if (prev==nullptr) head = head->link();
      else prev->set_link(p->link());
      if (p == tail) tail = prev;
      delete p;
      return true;
    }
    prev = p;
  }
  return false;
}

template<typename T> // count and erase all elems with target data
size_t LBag<T>::erase(const T & target) {
  size_t count = 0;
  while (erase_one(target)) count++; // can use this inefficient implementation
  return count;
}


/* OUT-OF-LINE NON-MEMBER FUNCTION DEFINITIONS RELATED TO NODE CLASS */

template<typename T> // insert data of each elem starting from head into out
std::ostream& operator <<(std::ostream& out, const node<T> * head) {
  for (const node<T> * p=head; p!=nullptr; p=p->link()) {
    out << p->data() << " ";
  }
  return out;
}

template<typename T> // count #nodes from head to nullptr
std::size_t list_size(const node<T> * head) {
  int count=0;
  for (const node<T> * p=head; p!=nullptr; p=p->link()) {
    count++;
  }
  return count;
}

template<typename T> // put new node with specified val before head of list
void list_insert_head(node<T>*& head, node<T>*& tail, const T& val) {
  head = new node<T>(val,head);
  if (tail==nullptr) tail=head;
}

template<typename T> // put new node with specified val behind tail of list
void list_insert_tail(node<T>*& head, node<T>*& tail, const T& val) {
  if (tail==nullptr) {
    list_insert_head(head,tail,val);
    return;
  }
  tail->set_link(new node<T>(val,nullptr));
  tail = tail->link();
}

template<typename T> // remove first node from list
void list_remove_head(node<T>*& head, node<T>*& tail) {
  if (head==nullptr) return;
  node<T>* second = head->link();
  delete head;
  head = second;
  if (second==nullptr) tail = nullptr;
}

template<typename T> // remove last node from list
void list_remove_tail(node<T>*& head, node<T>*& tail) {
  if (head==tail) {
    if (head==nullptr) return;
    delete head;
    head = tail = nullptr;
    return;
  }
  node<T> *pen;
  for (pen=head; pen->link()!=tail; pen=pen->link());
  delete tail;
  tail = pen;
  tail->set_link(nullptr);
}

#endif
