/* Q1, CSCI 60 final exam, 3/16/20

   I confirm that the only sources used on this exam are my class notes,
   my own code, material on camino, the book, and general online resources.
   I have not communicated with any other students while taking this exam,
   and I will not communicate after the exam with students who have not yet
   taken their final for this class. I understand that failure to uphold this
   pledge will result in a zero grade.

   Samuel Vivian

 */

#include <iostream>
#include "lbag.h"

using namespace std;

/* Q1: DEFINE AND IMPLEMENT YOUR CLASS HERE */
template <typename T>
class CappedLBag : public LBag
{
public:
CappedLBag(T max);
void insert(const T & target);
void increase_length(const T& more);
private:
  int max_length;
  T max_val;
};

template <typename T>
CappedLBag::CappedLBag(T max):LBag(){
  max_length = 0;
  max_val = max;
}

template <typename T>
void CappedLBag::insert(const T & target) {
  if(size()==max_length) return;
  if(target > T max_val) return;
  list_insert_head(head,tail,target);
}

template <typename T>
void CappedLBag::increase_length(const T & more) {
  max_length = more;
}
// use this for testing; as long as it compiles you will not be graded on it
int main() {
  CappedLBag<int> c(4);
  c.increase_length(6);
  for (int i=0; i<5; i++) c.insert(i+1);
  for (auto elem : b) cout << elem << ",";
  cout << endl;

  LBag<int> b;
  for (int i=0; i<5; i++) b.insert(i+1);
  cout << "Contents output with insertion: " << b << endl;
  cout << "Contents output with iterator:  ";
  for (auto elem : b) cout << elem << ",";
  cout << endl;
  return 0;
}
