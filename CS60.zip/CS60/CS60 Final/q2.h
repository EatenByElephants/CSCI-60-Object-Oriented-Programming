// Q2 final exam starter code: declaration for Q2; don't modify or upload!
// Sara Krehbiel, 3/16/20

bool foo(int *, int);
