/* Q3, CSCI 60 final exam, 3/16/20

   I confirm that the only sources used on this exam are my class notes,
   my own code, material on camino, the book, and general online resources.
   I have not communicated with any other students while taking this exam,
   and I will not communicate after the exam with students who have not yet
   taken their final for this class. I understand that failure to uphold this
   pledge will result in a zero grade.

   Samuel Vivian

 */

#include <iostream>
using namespace std;

class node { // fully implemented
public:
  node(int data = 0, node * link = nullptr): data_(data), link_(link) {}
  void set_data(int val) { data_ = val; }
  void set_link(node * p) { link_ = p; }
  int data() const { return data_; }
  node* link() const { return link_; }
private:
  int data_;
  node* link_;
};

/* PART A: IMPLEMENT YOUR 3 NON-MEMBER CYCLE FUNCTIONS HERE */
node* makeCycle(int * a, int n){
  node * start;
  node * temp;
  for(int i = n; i>0; i--){
    if(i-1==n){
      start = new node(a[i-1],start);
      temp->set_link(start);
    }else if(i-1==0){
      start = new node(a[i-1],start);
      (temp->link())->set_link(start);
    }else{
    start = new node(a[i-1],start);
    }
  }
}

void snip(node * start){
  for(node*p = start->link(); p!=start; p=p->link()){
    if(p->link()==start){
    (p->link())->set_link(nullptr);
  }
  }
}

bool isCycle(node * start){
  for(node*p = start->link(); p!=start; p=p->link()){
    if((p->link())==start) return true;
  }
  return false;
}


// a fully implemented iterator for a class with cyclic data
class C_iterator {
public:
  C_iterator(node * s = nullptr, node * c = nullptr) : start(s), curr(c) {}
  int operator *() const { return curr->data(); }
  C_iterator& operator ++() {
    curr = curr->link(); // move current pointer to the next node in the cycle
    if (curr==start) curr = nullptr; // if you just looped back to the beginning
    return (*this);
  }
  C_iterator operator ++(int) {
    C_iterator initIt(start,curr);
    ++(*this);
    return initIt;
  }
  bool operator ==(const C_iterator& rhs) const { return (start==rhs.start&&curr==rhs.curr);}
  bool operator !=(const C_iterator& rhs) const { return (start!=rhs.start||curr!=rhs.curr);}
private:
  node *start, *curr;
  // start always points to first node; curr updates as the iterator increments
};

// a skeletal Cycle class
class Cycle {
public:

  /* PART B: PARTIALLY HANDLE DYNAMIC MEMORY FOR THE CYCLE CLASS */
Cycle(int a[], int n){
  makeCycle(a,n);
}

~Cycle(){
  while(start!=nullptr){
    if (start==nullptr) return;
    node* second = start->link();
    delete start;
    start = second;
  }
}

//For good memory management you would want a erase_one function and an insert function.
//The erase would be implemented by looping through the cycle to find the target.
//Then keeping track of the previous it would set_link to next and then delete the current node.
//The insert would make a new node set its pointer to start and then reset start to point at it.

  /* PART C: ADD ITERATOR FUNCTIONALITY */
typedef C_iterator iterator;

iterator begin() {return start;}
iterator end() {
  for(node* p = start->link(); p!=start; p=p->link()){
    if(p->link()==start){
    return p;
    }
  }
}

private:
  node *start; // always points to the first node in a cycle
};


int main() {
  // use main for testing; as long as it compiles you will not be graded on it
  // test code for part c is below:

  int arr[3] = {1,2,3};
  Cycle c(arr,3);
  for (auto e : c) cout << e << "->";
  cout << endl;

  return 0;
}
