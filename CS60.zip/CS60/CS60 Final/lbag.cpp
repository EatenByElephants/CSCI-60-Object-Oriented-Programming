// Q3 final exam starter code: dummy implemetation; don't modify or upload!
// Sara Krehbiel, 3/16/20

#include "lbag.h"
