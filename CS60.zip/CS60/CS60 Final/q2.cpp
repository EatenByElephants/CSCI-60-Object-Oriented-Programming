/* Q2, CSCI 60 final exam, 3/16/20

   I confirm that the only sources used on this exam are my class notes,
   my own code, material on camino, the book, and general online resources.
   I have not communicated with any other students while taking this exam,
   and I will not communicate after the exam with students who have not yet
   taken their final for this class. I understand that failure to uphold this
   pledge will result in a zero grade.

   Samuel Vivian

 */

#include <iostream>
#include "q2.h"

using namespace std;

/* Q2: IMPLEMENT YOUR FUNCTION HERE */
bool foo(int * a, int n){
  if(a==nullptr){return true;}
  int i = 0;
  int i2 = n-1;
  if(a[i]!=a[i2]) {return false;}
  else{
    int b[n-2];
    for(int j = 1; j<n-2;j++){
      b[j-1]=a[j];
    }
    if(n-2==0||n-2==1){return true;}
    foo(b,n-2);
  }
}



// you can use a main function to test, but comment it out before uploading

int main() {
int sa[5] = {2,3,2};
cout << foo(sa,3)<<endl;
 cout << foo(nullptr,0) << endl; //1
  return 0;
 }
