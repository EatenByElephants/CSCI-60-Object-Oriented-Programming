//Samuel Vivian
#include <string>
#include <iostream>
using namespace std;

//declaration of base class
class Assignment {
public:
  //has 0 arg and 2 arg construtors
  Assignment() : name("-"), maxScore(100.0) {}
  Assignment(string name, double maxScore) : name(name), maxScore(maxScore) {}

//has two getters, one for each private variable
  double getMax() { return maxScore; }
  string getName() {return "Assignement Name: " + name; }

//has two private variables: assignment name and maximum achievable score
private:
  string name;
  double maxScore;
};

//declaration of inherited class
class finishedAssignment : public Assignment {
public:
  //has 0 arg and 4 arg constructors
  finishedAssignment() : Assignment(), studentName("-"), score(0) {}
  finishedAssignment(string name, double maxScore, string studentName, double score) : Assignment(name,maxScore), studentName(studentName), score(score) {}

//has an altered getter allowing the student to title their assignment
  string getName(string title){return "Student Given Name: " + title; }

//has new getters for new private variables
  string getSName(){return studentName;}
  double getScore(){return score;}

  // declaration for new funciton that calculates grade in percentage
  double calcPercentage();

//has two new private variables: student name and a raw score
private:
  string studentName;
  double score;
};

//defines funciton to calculate score percentage
double finishedAssignment::calcPercentage(){
  int p = (getScore()/getMax())*100;
  return p;
}


//driver to test working of abive classes
int main() {

  Assignment Exam("Paper 1",10);
  cout<<"Max Score: "<<Exam.getMax()<<endl;
  cout << Exam.getName() << endl << endl;

  finishedAssignment Homework("Paper 1",100,"Sam Vivian",98.4);
  cout<<"Max Score: "<<Homework.getMax()<<endl;
  cout << Homework.getName("The Development of Computer Science History") << endl;
  cout<<"Student Name: "<<Homework.getSName()<<endl;
  cout<<"Score: "<<Homework.getScore()<<endl;
  cout<<"Grade: "<<Homework.calcPercentage()<<"%"<<endl;

  return 0;
}
