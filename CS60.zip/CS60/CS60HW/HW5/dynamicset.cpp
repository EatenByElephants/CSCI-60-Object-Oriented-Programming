// HW5 Q1 starter implementation file for DynamicSet
// Samuel Vivian

#include "dynamicset.h"

//contains: using size and [], find if a given value is present
bool DynamicSet::contains(int target) const{
  int count=0;
  for(size_t i = 0; i<size();i++){
    if(target==DynamicBag::operator[](i)){
      return true;
    }
    count++;
  }
if(count==size()){
      return false;
  }
}

//remove: using erase_one removes a target value from the set
void DynamicSet::remove(int target) {
  erase_one(target);
}

//insert: using contains adds target value iff it is not already present
void DynamicSet::insert(int target) {
    if(!contains(target)){
      DynamicBag::insert(target);
    }
}
