// HW5 Q1 starter header file for DynamicSet, which should inherit DynamicBag
// Samuel Vivian

#ifndef DYNAMICSET_H
#define DYNAMICSET_H

#include "dynamicbag.h"

using std::size_t;

//class definition for DynamicSet
class DynamicSet: public DynamicBag
{
public:
void insert(int target);
void remove(int target);
bool contains(int target) const;
};

#endif
