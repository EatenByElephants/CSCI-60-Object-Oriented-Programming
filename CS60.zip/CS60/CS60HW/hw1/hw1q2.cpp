// Starter file for Homework 1, Question 2; due before class 1/15/20
// Samuel Vivian

#include <iostream>
#include <string>
using namespace std;

class MazeRacer {
private:
  string name;
  int coords[2];
  int moves;
public:

  int getMove(){
    return moves;
  }

  int getX(){
    return coords[0];
  }

  int getY(){
    return coords[1];
  }

  string getName(){
    return name;
  }

  MazeRacer(string n){
    name=n;
    coords[0]=0;
    coords[1]=0;
    moves=0;
  }
  MazeRacer(string n, int h, int v, int m){
    name=n;
    coords[0]=h;
    coords[1]=v;
    moves=m;
  }

  void moveLeft(){
    coords[0]--;
    moves++;
  }
  void moveRight(){
    coords[0]++;
    moves++;
  }
  void moveDown(){
    coords[1]--;
    moves++;
  }
  void moveUp(){
    coords[1]++;
    moves++;
  }
};

void moveRacer(MazeRacer& racer);
void checkDestination(MazeRacer racer, int tx, int ty);

int main() {
  string name1, name2;
  int coordinates[2];
  cout << "Enter a name for the first maze competitor: ";
  cin>>name1;
  MazeRacer racer1(name1); // first get name then construct racer1 accordingly

  cout << name1<< " will start at (0,0).\n";

  cout << "Enter a name for the second maze competitor: ";
  cin>>name2;
  cout << "Enter starting coordinates for "<<name2<<": ";
  cin>>coordinates[0]>>coordinates[1];
  MazeRacer racer2(name2,coordinates[0],coordinates[1],0); // get name and coordinates; construct racer2 accordingly

  cout << "Enter the target coordinates: ";
  int tx, ty; // populate target coordinates
  cin>>tx>>ty;

  // implement moveRacer to get move sequence from user
  moveRacer(racer1);
  moveRacer(racer2);

  // implement checkDestination to see whether targets are reached
  checkDestination(racer1, tx, ty);
  checkDestination(racer2, tx, ty);
  return 0;
}

// get move sequence from user and move racer accordingly
void moveRacer(MazeRacer& racer) {
  cout << "Enter a sequence of moves (LRUD) for "<<racer.getName()<<endl;
  string seq;
  cin >> seq;
  for (int i=0; i<seq.length(); i++) {
    // move racer depending on the direction specified by seq.at(i)
    if(seq[i]=='L'){racer.moveLeft();}
    else if(seq[i]=='R'){racer.moveRight();}
    else if(seq[i]=='D'){racer.moveDown();}
    else if(seq[i]=='U'){racer.moveUp();}
    //Add move increment!!!
  }
}

// report whether racer is at (tx,ty)
void checkDestination(MazeRacer racer, int tx, int ty) {
  if (racer.getX()==tx&&racer.getY()==ty) { // replace this condition with an appropriate one
    cout << racer.getName()<<" was at the target after " <<racer.getMove()<<" moves\n";
  } else {
    cout << racer.getName()<<" was not at the target after " <<racer.getMove()<<" moves\n";
  }
}
