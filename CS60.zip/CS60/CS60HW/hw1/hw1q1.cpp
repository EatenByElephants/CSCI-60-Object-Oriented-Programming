// Starter file for Homework 1, Question 1; due before class 1/15/20
// Samuel Vivian

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

const int N_ROLLS = 200; // how many rolls to simulate
const string DATA_FILENAME = "data.txt";
const string HIST_FILENAME = "hist.txt";

int getRoll() {return (rand()%6+rand()%6+2);}
// returns the value (between 2 and 12) of a toss of a pair of random dice

void simulateAndRecord();
// Pre:  No meaningful data is in either file
// Post: Results of simulation of N_ROLLS pairs of dice are in DATA_FILENAME

void produceHistogram();
// Pre:  DATA_FILE contains (at most) N_ROLLS values 2-12;
//       HIST_DATA has no meaningful info; both files are closed
// Post: For each val 2-12, HIST_FILE contains a line of stars
//       counting the # times that val appears in DATA_FILE

void writeLineOfStars(int rolls[], int nRolls, int val, ostream& out);
// Pre:  rolls array contains nRolls simulations; out is an opened output file
// Post: The val line of the histogram has been appended to out, e.g., if val=3
//       and 3 occured 5 times, the line would be "3: *****"

int main() {
  simulateAndRecord();
  produceHistogram();
  return 0;
}

// simulate rolling N_ROLLS pairs of dice; record values in DATA_FILENAME
void simulateAndRecord() {
  ofstream datafile(DATA_FILENAME); // open DATA_FILENAME
  for (int i=0; i<N_ROLLS; i++) {
    datafile << getRoll() << endl; // simulate 1 roll and output it to datafile
  }
  datafile.close(); // close the file
}

void produceHistogram() {
  /* TODO: implement this function; define writeLineOfStars helper */
  int rolls[N_ROLLS];
  int count=0;
  ifstream datafile(DATA_FILENAME);
    while(!datafile.eof()) {
    datafile>>rolls[count];
    count++;
  }
  datafile.close();

  int counts[11];

for(int k=0; k<11; k++){
  counts[k]=0;
}

  for(int i=0;i<N_ROLLS;i++){
    if(rolls[i]==2){counts[0]++;
  }else if(rolls[i]==3){counts[1]++;
  }else if(rolls[i]==4){counts[2]++;
  }else if(rolls[i]==5){counts[3]++;
  }else if(rolls[i]==6){counts[4]++;
  }else if(rolls[i]==7){counts[5]++;
  }else if(rolls[i]==8){counts[6]++;
  }else if(rolls[i]==9){counts[7]++;
  }else if(rolls[i]==10){counts[8]++;
  }else if(rolls[i]==11){counts[9]++;
  }else {counts[10]++;
  }
}

ofstream histfile(HIST_FILENAME);

for(int i=0; i<11; i++){
  histfile<<i+2<<": ";
  for(int j=0; j<counts[i];j++){
    histfile<<"*";
  }
  histfile<<endl;
}

}
