// Implementation starter file for Homework 2; due 5pm 1/23/20
// Samuel Vivian

#include "skittlesbag.h"
#include "skittlesdish.h"
//#include "skittlesdish.cpp"

//Default Constructor for SkittlesBag
SkittlesBag::SkittlesBag(){
  for(int i=0; i<5; i++){
    counts[i]=0;
  }
  sizes=0;
}

//Constructor for SkittlesBag
SkittlesBag::SkittlesBag(int r, int y, int g, int o, int p){
counts[0]=r;
counts[1]=y;
counts[2]=g;
counts[3]=o;
counts[4]=p;
sizes=(counts[0]+counts[1]+counts[2]+counts[3]+counts[4]);
}

//Getter for counts of SkittlesBag depending on input color
int SkittlesBag::count(char color) const{
  if (color == 'r'){
    return counts[0];
  }else if(color == 'y'){
    return counts[1];
  }else if(color == 'g'){
    return counts[2];
  }else if(color == 'o'){
    return counts[3];
  }else if(color == 'p'){
    return counts[4];
  }else{
    return 0;
  }
}

//Getter for size of SkittlesBag
int SkittlesBag::size()const{
  return sizes;
}


//Prints histogram for give SkittlesBag hsowing counts of each color
void SkittlesBag::printHistogram(){
  char colors[5]={'r','y','g','o','p'};
  for(int j=0;j<5;j++){
    cout<<colors[j]<<": ";
    for(int i=0;i<counts[j];i++){
      cout<<"*";
    }
    cout<<endl;
  }

}

//Adds one skittle of input color to SkittlesBag
void SkittlesBag::addOne(char color){
  if (color == 'r'){
    counts[0]++;
  }else if(color == 'y'){
    counts[1]++;
  }else if(color == 'g'){
    counts[2]++;
  }else if(color == 'o'){
    counts[3]++;
  }else if(color == 'p'){
    counts[4]++;
  }
  sizes++;
}

//Removes the specified amount from the specified color of skittles in SkittlesBag *munch*
void SkittlesBag::eat(int amt, char color){
  if (color == 'r'){
      if(amt<counts[0]){
        counts[0]=counts[0]-amt;
    }else{counts[0]=0;
  }}else if(color == 'y'){
    if(amt<counts[1]){
    counts[1]=counts[1]-amt;
  }else{counts[1]=0;
  }}else if(color == 'g'){
    if(amt<counts[2]){
    counts[2]=counts[2]-amt;
  }else{counts[2]=0;
  }}else if(color == 'o'){
    if(amt<counts[3]){
    counts[3]=counts[3]-amt;
  }else{counts[3]=0;
  }}else if(color == 'p'){
    if(amt<counts[4]){
    counts[4]=counts[4]-amt;
  }else{counts[4]=0;
  }
}
sizes=sizes-amt;
}

//The "Sam Vivian" function... those colors gotta be even. Takes min amount away to make all counts even
void SkittlesBag::evenOut(){
  int min = 100000;
  int r = counts[0];
  int y = counts[1];
  int g = counts[2];
  int o = counts[3];
  int p = counts[4];

for(int i=0;i<5;i++){
  if(counts[i]<min){
    min=counts[i];
  }
}


for(int j=0;j<5;j++){
  counts[j]=min;
}

cout<<r-min<<" red eaten"<<endl;
cout<<y-min<<" yellow eaten"<<endl;
cout<<g-min<<" green eaten"<<endl;
cout<<o-min<<" orange eaten"<<endl;
cout<<p-min<<" purple eaten"<<endl;
cout<<min<<" of each color remain"<<endl;

sizes=(counts[0]+counts[1]+counts[2]+counts[3]+counts[4]);
}


//Adds contenst of input SkittlesDish to SkittlesBag and empties the dish
void SkittlesBag::pourInDish(SkittlesDish& a){
  if(a.getColor()=="red"){
    counts[0]=counts[0]+a.getCount();
  }else if(a.getColor() == "yellow"){
    counts[1]=counts[1]+a.getCount();
  }else if(a.getColor() == "green"){
    counts[2]=counts[2]+a.getCount();
  }else if(a.getColor() == "orange"){
    counts[3]=counts[3]+a.getCount();
  }else if(a.getColor() == "purple"){
    counts[4]=counts[4]+a.getCount();
  }
  int remove = a.getCount();
  a.eatSkittles(remove);

  sizes=(counts[0]+counts[1]+counts[2]+counts[3]+counts[4]);
}

//Overloads operator += to add the contens of the rhs to the lhs and empty the rhs
void SkittlesBag::operator += (SkittlesBag& rhs){
  char color[5]={'r','y','g','o','p'};
  for(int i=0;i<5;i++){
    counts[i]=counts[i]+ rhs.count(color[i]);
  }
  for(int j=0;j<5;j++){
    rhs.eat(rhs.count(color[j]),color[j]);
  }

}

//Overloads the == operator to check whehter or no the contents of two SkittlesBags are equal
bool operator == (const SkittlesBag& lhs, const SkittlesBag& rhs){
  if((lhs.count('r')==rhs.count('r'))&&(lhs.count('y')==rhs.count('y'))&&(lhs.count('g')==rhs.count('g'))&&(lhs.count('o')==rhs.count('o'))&&(lhs.count('p')==rhs.count('p'))){
    return true;
  }else{
    return false;
  }
}
