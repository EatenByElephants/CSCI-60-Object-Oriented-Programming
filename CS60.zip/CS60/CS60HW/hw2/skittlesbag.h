// Interface starter file for Homework 2; due 5pm 1/23/20
// Samuel Vivian

#ifndef SKITTLESBAG_H
#define SKITTLESBAG_H

#include "skittlesdish.h"
#include <iostream>

using std::cout;

class SkittlesBag {
public:
SkittlesBag();
SkittlesBag(int r, int y, int g, int o, int p);
int count(char color) const;
int size()const;
void printHistogram();
void addOne(char color);
void eat(int amt, char color);
void evenOut();
void pourInDish(SkittlesDish& a);
void operator += (SkittlesBag& rhs);

private:
int counts[5];
int sizes;
};

bool operator == (const SkittlesBag& lhs, const SkittlesBag& rhs);

#endif
