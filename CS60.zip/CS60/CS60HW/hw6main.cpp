// HW6 starter file
// Samuel Vivian

#include <iostream>
#include <vector>

using namespace std;

/* Part 1 */
//outputs vectors in a list
template <typename T>
ostream& operator <<(ostream& out, const vector<T>& r) {
  for (typename vector<T>::size_type i = 0; i < r.size(); i++){
    if(i!=r.size()-1)
      out << r[i] <<", ";
    else
      out << r[i];
  }
  return out;
}



/* Part 2 */
template <typename T1, typename T2>
class Point{
public:
  Point() : x(0), y(0) {}
  Point(T1 x, T2 y) : x(x), y(y) {}
  T1 getX() const {return x;}
  T2 getY() const {return y;}
  Point operator + (const Point& rhs) const; //adds Points
private:
  T1 x;
  T2 y;
};

//out of line + def
template <typename T1, typename T2>
Point<T1,T2> Point<T1,T2> :: operator +(const Point& rhs) const{
  T1 a = x + rhs.x;
  T2 b = y + rhs.y;
  Point p1(a,b);
  return p1;
}

//template << overload in the form (T1,T2)
template <typename T1, typename T2>
ostream& operator<<(ostream& out, const Point<T1,T2>& p){
  out << "(" << p.getX() << ", " << p.getY() << ")";
  return out;
}



/* Part 3 */
class Rational {
public:
  Rational(int n, int d) : n(n), d(d) { reduce(); } // sets up n/d, reduced
  Rational(int n) : n(n), d(1) {} // sets up n/1
  Rational() : n(0), d(1) {} // sets up 0/1
  int getN() const { return n; }
  int getD() const { return d; }
  double getVal() const { return 1.0*n/d; } // returns the double value
  void set(int n, int d) { this->n = n; this->d = d; reduce(); } // sets values
  void reduce(); // reduces fractions
  Rational operator +(const Rational& rhs) const; //adds fractions
private:
  int n, d;
};

//Allows fraction output
ostream& operator <<(ostream& out, const Rational& r){
  if(r.getD() != 1){
    out << r.getN() << "/" << r.getD();
    return out;
  }
  out << r.getN();
  return out;
}

//out of line reduce def
void Rational::reduce(){
  if (d < 0){
    d *= -1;
    n *= -1;
  }
  for(int i = abs(n * d); i > 1; i--){
    if(n % i == 0 && d % i == 0){
      n /= i;
      d /= i;
    }
  }
}

//out of line + def
Rational Rational::operator +(const Rational& rhs) const{
  int u = this->n*rhs.d + rhs.n*this->d;
  int b = this->d*rhs.d;
  Rational result(u,b);
  result.reduce();
  return result;
}

/* Part 4 */
int main() {

  //Part 1 Test
  vector<int> intVec;
  intVec.push_back(2);
  intVec.push_back(4);
  intVec.push_back(4);
  intVec.push_back(-1);
  cout << intVec << endl;

  //Part 2 Test
  Point<int, double> p1(1,0.6);
  Point<int, double> p2(4,0.8);
  cout << p1 + p2 << endl;

  //Part 3 Test
  //Test 3a
  Rational f1(18,66);
  Rational f2(3,-6);
  Rational f3(-8,-4);
  f1.reduce();
  f2.reduce();
  f3.reduce();
  cout << f1 << endl;
  cout << f2 << endl;
  cout << f3 << endl;

  //Test 3b
  vector<Rational> rationalVec;
  rationalVec.push_back(f1);
  rationalVec.push_back(f2);
  rationalVec.push_back(f3);
  cout << rationalVec<<endl;

  //Test 3c: tests x as double, y as rational
  Rational f4(3,11);
  Point<double, Rational> p3(1.4, f4);
  vector <Point<double, Rational> > pointVec;
  pointVec.push_back(p3);
  cout << pointVec << endl;

return 0;
}
