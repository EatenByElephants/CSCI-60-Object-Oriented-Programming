// Implementation file for HW8
// Samuel Vivian

#include "node.h"

// 2-arg node constructor
node::node(const value_type& data, node * link) : data_(data), link_(link) {}

// overloaded << for debugging
std::ostream& operator <<(std::ostream& out, const node * head) {
  for (const node* p=head; p!=nullptr; p=p->link()) {
    out << p->data() << " ";
  }
  return out;
}

// TODO: your implementations go here!

//recursively computes nth item in given sequence
int sequence(int n) {
  if(n<2) return 1;
  else return sequence(n-2)+n-1;
 }

//recursively removes head until head and tail are nullptr
void list_clear(node * & head_ptr, node * & tail_ptr) {
  if(head_ptr == nullptr&&tail_ptr == nullptr) return;
  else if(head_ptr==tail_ptr){
    delete head_ptr;
    head_ptr = tail_ptr = nullptr;
  }else{
    node * temp = head_ptr->link();
    delete head_ptr;
    head_ptr= temp;
    list_clear(head_ptr, tail_ptr);
  }
}

//recursively swaps terms startign from first and last going inward until
//start and end reach the middle of the array
void reverse(int a[], int start, int end) {
if(start==end||end<start) return;
else {
    int temp = a[start];
    a[start]= a[end];
    a[end] = temp;
    reverse(a,start+1,end-1);
  }
}

//changes the direction of each link and then swaps head and tail ptrs
//thus reversing the linked list
void list_reverse(node*& head, node*& tail) {
  node * current = head;
  node * last = nullptr, * next = nullptr;
  while (current != nullptr){
    next = current->link();
    current->set_link(last);
    last = current;
    current = next;
  }
  tail = head;
  head = last;
 }
