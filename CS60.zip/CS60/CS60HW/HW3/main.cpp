#include <iostream>
#include "biguint.h"

using namespace std;

int main(){
  biguint result("12");
  biguint result2("34");
  biguint result3("12");

  cout<<result2.toString()<<endl;

}
