//Samuel Vivian
//Lab Partner: Brian Goodson

#include <iostream>
#include <string>
#include "biguint.h"


//default constructor
biguint::biguint(){
  for(std::size_t i = 0;i < CAPACITY;i++){
    data_[i] = 0;
  }


}

//Construtor taking in the string. Subtracts character 0 to find the actual digit
biguint::biguint(const std::string & y){
  int k = 0;
  for(std::size_t j = y.length()-1;j > 0;j--){
    data_[k] = y[j] - '0';
    k++;
  }
  data_[y.length()-1] = y[0] - '0';
  for(std::size_t i = y.length();i < CAPACITY;i++){
    data_[i] = 0;
  }


}

//Returns index within []
unsigned short biguint::operator [](std::size_t pos) const {
  if(pos > CAPACITY){
    return 0;
  }
  else{
    return data_[pos];
  }
}

//Allows printing of biguint
std::ostream & operator << (std::ostream&out, const biguint & b){
  for(std::size_t i = biguint::CAPACITY-1; i > 0;i--){
    out<<b[i];
  }
  out<<b[0];
  return out;
}

//Allows += of two biguints
void biguint::operator += (const biguint & b){
  int add = 0;
  int carry = 0;
  for(std::size_t i = CAPACITY - 1;i > 0;i--){
    add = data_[i] + b.data_[i];
    if(add > 9){
      carry = 1;
    }
    else{
      carry = 0;
    }
    if(carry == 1){
      data_[i] = data_[i] + b.data_[i] + 1;
    }
    else{
      data_[i] = data_[i] + b.data_[i];
    }
  }
  if(add > 9){
    carry = 1;
  }
  else{
    carry = 0;
  }
  if(carry == 1){
    data_[0] = data_[0] + b.data_[0] + 1;
  }
  else{
    data_[0] = data_[0] + b.data_[0];
  }
}

//Adds two biguints and outputs result
biguint operator + (const biguint & a, const biguint & b){
  biguint result;
  result+=a;
  result+=b;
  return result;
}

//Compares two biguints
// returns 1 if this biguint > b
//               0 if this biguint == b
//              -1 if this biguint < b
int biguint::compare(const biguint & b) const{
  int count = 0;
  for(std::size_t i = biguint::CAPACITY - 1;i>0;i--){
if(data_[i]<b[i]){
  return -1;
  break;
}else if(data_[i]>b[i]){
  return 1;
  break;
}else{
  count++;
}
}
if(data_[0]<b[0]){
  return -1;
}else if(data_[0]>b[0]){
  return 1;
}else{
  count++;
}
if(count == biguint::CAPACITY){
  return 0;
}
}

//Returns true or false for <
bool operator < (const biguint &a, const biguint &b){
  int c = a.compare(b);
  if(c ==-1){
    return true;
  }else{
    return false;
  }
}

//Returns true or false for <=
bool operator <= (const biguint & a, const biguint & b){
  int c = a.compare(b);
  if(c==-1||c==0){
    return true;
  }else{
    return false;
  }
}

//Returns true or false for !=
bool operator != (const biguint &a, const biguint &b){
  int c = a.compare(b);
  if(c!=0){
    return true;
  }else{
    return false;
  }
}

//Returns true or false for ==
bool operator == (const biguint &a, const biguint &b){
  int c = a.compare(b);
  if(c==0){
    return true;
  }else{
    return false;
  }
}

//Returns true or false for >=
bool operator >= (const biguint &a, const biguint &b){
  int c = a.compare(b);
  if(c==1||c==0){
    return true;
  }else{
    return false;
  }
}

//Returns true or false for >
bool operator > (const biguint &a, const biguint &b){
  int c = a.compare(b);
  if(c==1){
    return true;
  }else{
    return false;
  }
}

//Allows -= of two biguints (absolute value of result)
void biguint::operator -= (const biguint & b){
  int sub = 0;
  int borrow = 0;
  for(std::size_t i = CAPACITY - 1;i > 0;i--){
    sub = data_[i] - b.data_[i];
    if(sub < 0){
      borrow = 1;
    }
    else{
      borrow = 0;
    }
    if(borrow == 1){
      data_[i] = (data_[i] - b.data_[i])*(-1);
    }
    else{
      data_[i] = data_[i] - b.data_[i];
    }
  }
  if(sub < 0){
    borrow = 1;
  }
  else{
    borrow = 0;
  }
  if(borrow == 1){
    data_[0] = (data_[0] - b.data_[0])*(-1);
  }
  else{
    data_[0] = data_[0] - b.data_[0];
  }
}

//Subtracts one biguint from another and outputs absolute value of result
biguint operator - (const biguint & a, const biguint & b){
  biguint result;
  result+=a;
  result-=b;
  return result;
}

//Reverses the constructer that intakes a string by adding back character 0
//Outputs biguint as a string
std::string biguint::toString(){
  std::string Int;
  for(std::size_t i = biguint::CAPACITY - 1;i > 0;i--){
  Int+= data_[i]+'0';
}
Int+=data_[0]+'0';
return Int;
}
