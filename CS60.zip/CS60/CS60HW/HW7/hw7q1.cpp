// Starter file for Question 1 or HW7, due Wed 2/26 before class
// Samuel Vivian
/*HYPOTHESIS: 3 will be fastest because sets automatically have no duplicates
and will self-sort. 1 is 2nd fastest because duplicates are removed before sorting
2 is slowest because you have to sort through all the words including duplicates
ANALYSIS: 3 was by far the easiest to develop as it required the least code and was
simple to do. 1 was next easiest and 2 was hardest ebcause it was dificult for me to
figure out how to not allow duplicates when they were allowed in the array. Algorithm 3
was fastest as expected with a time of 1.66132 seconds, algorithm 1 was second fastest at
513.018 seconds or about 9.5 minutes and algorithm 2 was slowest at 4212.8 seconds or
about 1 hour*/

#include <iostream>
#include <fstream>
#include <vector>
#include <set>

using namespace std;
using namespace std::chrono; // for timing experiments

const int EXPERIMENT = 3; // change this as you test your algorithms (1-3)
const string INFILE = "don_quixote.txt"; //"quickbrownfox.txt"; // test with DQ
const string OUTFILE = "output.txt"; // don't change this!

void timedExperiment(string filename, int exp);
void readWithVector1(string filename);
void readWithVector2(string filename);
void readWithSet(string filname);

// starts a timed experiment based on default values or command line arguments
int main(int argc, char** argv) {
  if (argc<2) timedExperiment(INFILE,EXPERIMENT); // test according to constants
  else timedExperiment(argv[1],stoi(argv[2])); // or use command line arguments
  return 0;
}

// runs specified experiment on the specified filename and reports the time
void timedExperiment(string filename, int exp) {
  auto start = high_resolution_clock::now();
  switch (exp) {
    case 1: readWithVector1(filename); break;
    case 2: readWithVector2(filename); break;
    case 3: readWithSet(filename); break;
    default: cout << "Invalid experiment number specified\n"; return;
  }
  auto stop = high_resolution_clock::now();
  auto duration = duration_cast<microseconds>(stop - start);
  cout << duration.count()/1000000.0 << " seconds for alg " << exp <<
    " to process " << filename << endl;
}

// TODO: implement these experiments!

void readWithVector1(string filename) {
  vector<string> Vector1;
  string a;
  ifstream in;
  in.open(filename);

  while(in>>a){
    int count = 0;
    for(int i=0; i<Vector1.size(); i++){
      if(a!=Vector1[i]){
        count++;
      }
    }
    if(count==Vector1.size()){
    Vector1.push_back(a);
  }
  }

  sort(Vector1.begin(),Vector1.end());
  in.close();

  ofstream out;
  out.open("output.txt");
  for(auto e: Vector1)
    out << e <<endl;
  out.close();
}

void readWithVector2(string filename) {
  vector<string> Vector2;
  string a;
  ifstream in;
  in.open(filename);
  while(in>>a){
      Vector2.push_back(a);
  }

  sort(Vector2.begin(),Vector2.end());
  in.close();

  ofstream out;
  out.open("output.txt");
  for(int j = 0; j<Vector2.size(); j++){
    int count = 0;
    for(int i = 0; i<j; i++){
      if(Vector2[j]!=Vector2[i]){
        count++;
      }
    }
      if(j s == count)  {
        out << Vector2[j] <<endl;
      }
  }
  out.close();
}

void readWithSet(string filename) {
  set<string> Set;
  string a;
  ifstream in;
  in.open(filename);
  while(in>>a){
    Set.insert(a);
  }
  in.close();

  ofstream out;
  out.open("output.txt");
  for(auto e: Set)
    out << e <<endl;
  out.close();

}
