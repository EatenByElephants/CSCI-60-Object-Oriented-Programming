// Starter file for Question 2 or HW7, due Wed 2/26 before class
// Samuel Vivian

#include <iostream>
#include <fstream>
#include <map>

using namespace std;

const string INFILE = "records.txt";

//keeps track of everything but ID which will be map key
struct Record{
public:
  string name;
  double gpa;
  string password;
};

int main() {
  map<int,Record> m;
  Record s;
  int a;
  ifstream in;
  in.open(INFILE);
  //loop stores all data in map from int(ID) to student struct
  while(!in.eof()){
    in >> s.name >> a >> s.password >> s.gpa;
    m[a]=s;
  }
  in.close();

int num = 1;

//interface to enter and check to make sure id and password exist and match
while (num!=0){
    cout << "Enter an ID number (enter 0 to quit): " << endl;
    cin >> num;
    if(num==0){
      cout<< "Goodbye!"<<endl;
      break;
    }else{
    cout << "Enter password: " << endl;
    string pass;
    cin >> pass;
  if(m[num].password == pass && m.find(num)!=m.end()) {
    cout << "Name: " << m[num].name << endl;
    cout << "GPA: " << m[num].gpa << endl;
  }else{
    cout << "That is the worng password." << endl;
  }
}
}

}
