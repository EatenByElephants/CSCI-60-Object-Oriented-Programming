#include <cstdlib>
#include <algorithm>
#include <ostream>
#include <iostream>
#include "dynamicset.h"

using namespace std;

int main(){

//check if constructors compile
DynamicSet result;
DynamicSet result1(result);

//insert a few values
result1.insert(1);
result1.insert(2);

//make sure repeats dont work
result1.insert(2);
result1.insert(3);

//checks contains function
cout<<"After inserting values the first set is: "<<result1<<endl;
cout<<"Does the first set have a 4 in it? "<<result1.contains(4)<<endl;
cout<<"Does the first set have a 3 in it? "<<result1.contains(3)<<endl;

//checks working of remove function
cout<<"Did a 3 get removed from the first set? "<<result1.remove(3)<<endl;
cout<<"After removing a 3 the first set is: "<<result1<<endl;

//checks +=
result.insert(6);
result.insert(7);
result.insert(8);
cout<<"After inserting values the second set is: "<<result<<endl;
result+=result1;
cout<<"After finding the union with the first set, the second set is: "<<result<<endl;

//checks *=
result*=result1;
cout<<"After finding the intersect with the first set, the second set is: "<<result<<endl;

//adds some values and then checks -=
result.insert(5);
result.insert(9);
result-=result1;
cout<<"After inserting a 5 and 9 and finsing the difference with the first set, the second set is: "<<result<<endl;

//checks that + works
cout<<"The union of the first and second set is: "<<result+result1<<endl;

//checks that * works
result.insert(1);
cout<<"After adding a 1 to the second set, the union of the first and second set is: "<<result*result1<<endl;

//checks that - works
cout<<"The difffernce of the second and first set is: "<<result-result1<<endl;

}
