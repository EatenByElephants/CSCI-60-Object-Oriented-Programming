// Download and run this in advance to iron out any kinks with
// getting started programming with starter files!

#include <iostream>
using namespace std;

int main() {
  cout << "Hello, world!\n";
  return 0;
}
